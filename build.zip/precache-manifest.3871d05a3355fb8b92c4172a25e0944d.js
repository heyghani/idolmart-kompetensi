self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "29f458c1ee1f83dba0b89468f2f15bff",
    "url": "/index.html"
  },
  {
    "revision": "54b6ae76de3d090d7038",
    "url": "/static/css/2.44d09fed.chunk.css"
  },
  {
    "revision": "2d151dda03b54189a403",
    "url": "/static/css/main.ebe0d7b6.chunk.css"
  },
  {
    "revision": "54b6ae76de3d090d7038",
    "url": "/static/js/2.949be13d.chunk.js"
  },
  {
    "revision": "2d151dda03b54189a403",
    "url": "/static/js/main.09e0e65d.chunk.js"
  },
  {
    "revision": "dfdba732dcb179e5dd8a",
    "url": "/static/js/runtime~main.64b70b7b.js"
  },
  {
    "revision": "f38ddea9dedadea03c5d43c596dac13f",
    "url": "/static/media/argon-react.f38ddea9.png"
  },
  {
    "revision": "3897e68864e7fe1fbb468c0220573010",
    "url": "/static/media/fa-brands-400.3897e688.svg"
  },
  {
    "revision": "48461ea4e797c9774dabb4a0440d2f56",
    "url": "/static/media/fa-brands-400.48461ea4.woff2"
  },
  {
    "revision": "7b464e274bc331f9a765d765359635a5",
    "url": "/static/media/fa-brands-400.7b464e27.woff"
  },
  {
    "revision": "947b9537bc0fecc8130d48eb753495a1",
    "url": "/static/media/fa-brands-400.947b9537.ttf"
  },
  {
    "revision": "9b6c8da3c489424e2b3e9c9fb6314b37",
    "url": "/static/media/fa-brands-400.9b6c8da3.eot"
  },
  {
    "revision": "381af09a1366b6c2ae65eac5dd6f0588",
    "url": "/static/media/fa-regular-400.381af09a.woff"
  },
  {
    "revision": "6d4774d4e483e03057f9d09544656b42",
    "url": "/static/media/fa-regular-400.6d4774d4.svg"
  },
  {
    "revision": "73fe7f1effbf382f499831a0a9f18626",
    "url": "/static/media/fa-regular-400.73fe7f1e.ttf"
  },
  {
    "revision": "7422060ca379ee9939d3b687d072acad",
    "url": "/static/media/fa-regular-400.7422060c.eot"
  },
  {
    "revision": "949a2b066ec37f5a384712fc7beaf2f1",
    "url": "/static/media/fa-regular-400.949a2b06.woff2"
  },
  {
    "revision": "0079a0ab6bec4da7d6e16f2a2e87cd71",
    "url": "/static/media/fa-solid-900.0079a0ab.ttf"
  },
  {
    "revision": "14a08198ec7d1eb96d515362293fed36",
    "url": "/static/media/fa-solid-900.14a08198.woff2"
  },
  {
    "revision": "3fad11457f70f880252e0ab5c9cee82e",
    "url": "/static/media/fa-solid-900.3fad1145.svg"
  },
  {
    "revision": "70e65a7d34902f2c350816ecfe2f6492",
    "url": "/static/media/fa-solid-900.70e65a7d.eot"
  },
  {
    "revision": "815694de1120d6c1e9d1f0895ee81056",
    "url": "/static/media/fa-solid-900.815694de.woff"
  },
  {
    "revision": "48d48609c84c2eb311d0b8cdc2fb06f5",
    "url": "/static/media/idolmart.48d48609.PNG"
  },
  {
    "revision": "f88e23c415fda5c5900bdea790886bd6",
    "url": "/static/media/idolmart.f88e23c4.jpeg"
  },
  {
    "revision": "2569aaea6eaaf8cd210db7f2fa016743",
    "url": "/static/media/nucleo-icons.2569aaea.woff"
  },
  {
    "revision": "426439788ec5ba772cdf94057f6f4659",
    "url": "/static/media/nucleo-icons.42643978.woff2"
  },
  {
    "revision": "46abbc4a676739dbd61f8a305cb63fd8",
    "url": "/static/media/nucleo-icons.46abbc4a.svg"
  },
  {
    "revision": "c1733565b32b585676302d4233c39da8",
    "url": "/static/media/nucleo-icons.c1733565.eot"
  },
  {
    "revision": "f82ec6ba2dc4181db2af35c499462840",
    "url": "/static/media/nucleo-icons.f82ec6ba.ttf"
  },
  {
    "revision": "53033970a416368da35794389680266f",
    "url": "/static/media/team-1-800x800.53033970.jpg"
  }
]);